import { pool } from "../models/MonthlyBudget.js";
import { getKigaliTime } from "../utils/kigaliTime.js";
import { calculateFinancialHealth } from "../utils/financialHealthScore.js";
import {
  MAX_SHIFT_LETTERS,
  ensureDailyLetterTable,
  getDailyPacingStatus,
  getShiftLeaderboard,
  rankShiftLeaderboard,
  recordDailyLetters,
} from "../services/dailyLetterService.js";
import {
  sendDailyTargetReachedNotification,
  sendLeaderboardOvertakeNotification,
} from "../services/pushService.js";

const n = (v) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : 0;
};

const RATE_PER_LETTER = 245;

export const getDashboard = async (req, res) => {
  try {
    const kigali = getKigaliTime();

    const [rows] = await pool.query("SELECT * FROM MonthlyBudget WHERE id = 1");
    if (!rows.length) {
      return res.status(404).json({ error: "Budget row not found" });
    }
    const b = rows[0];
    const currentMonth = Number(b.month);
    const currentYear = Number(b.year);

    const [templates] = await pool.query(
      "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
    );
    const emergencyPct =
      templates.length > 0 ? n(templates[0].emergency_pct) : 0;

    const [expensesRows] = await pool.query(
      `SELECT IFNULL(SUM(amount), 0) AS totalSpent 
       FROM DailyExpense 
       WHERE MONTH(expenseDate) = ? AND YEAR(expenseDate) = ?`,
      [currentMonth, currentYear],
    );

    const [investmentRows] = await pool.query(
      `SELECT IFNULL(SUM(principal_invested), 0) AS totalPrincipal, 
              IFNULL(SUM(current_value), 0) AS totalValue 
       FROM ActualInvestments 
       WHERE month = ? AND year = ?`,
      [currentMonth, currentYear],
    );
    const currentInvestmentValue = n(investmentRows[0].totalValue);

    // Fetch actual saved balance from EmergencyFund table
    const [efRows] = await pool.query(
      "SELECT current_amount FROM EmergencyFund WHERE id = 1 LIMIT 1",
    );
    const actualEmergencyBalance =
      efRows.length > 0 ? n(efRows[0].current_amount) : n(b.emergencyFund);

    // Fetch static un-deposited emergency snapshot balances for the Pending Target Widget
    const [[snapshotRows]] = await pool.query(
      `SELECT 
         IFNULL(SUM(salary_allocation), 0) AS stagedSalaryEmergency, 
         IFNULL(SUM(side_income_allocation), 0) AS stagedSideEmergency 
       FROM PendingEmergencySnapshots 
       WHERE is_deposited = 0`,
    );
    const stagedSalaryPortion = n(snapshotRows?.stagedSalaryEmergency);
    const stagedSidePortion = n(snapshotRows?.stagedSideEmergency);
    const pendingEmergencyTotal =
      Math.round((stagedSalaryPortion + stagedSidePortion) * 100) / 100;

    const liveSalary = n(b.translatedLetters) * RATE_PER_LETTER;
    const liveIncome = liveSalary + n(b.otherIncome);
    const liveBalance = n(b.balance);

    // These balances are the same authoritative values shown in Investments.
    const [schoolFeeRows] = await pool.query(
      "SELECT cumulative FROM SchoolFees ORDER BY id DESC LIMIT 1",
    );
    const schoolFeesBalance = n(schoolFeeRows[0]?.cumulative);

    const [investmentReserveRows] = await pool.query(
      "SELECT amount FROM InvestmentReserve WHERE id = 1 LIMIT 1",
    );
    const investmentReserveBalance = n(investmentReserveRows[0]?.amount);

    await pool.query("UPDATE MonthlyBudget SET salary = ? WHERE id = 1", [
      liveSalary,
    ]);

    const plannedEssentials =
      n(b.rent) +
      n(b.phoneInternet) +
      n(b.electricityWater) +
      n(b.food) +
      n(b.miscellaneous) +
      n(b.medical) +
      n(b.familySupport);

    const day = kigali.day;
    const lastDayOfMonth = kigali.lastDayOfMonth;

    const isShift1 = day <= 15;
    const totalDaysInShift = isShift1 ? 15 : lastDayOfMonth - 15;
    const shiftDay = isShift1 ? day : day - 15;

    const shiftLetters = n(b.shiftLetters);
    const remainingToMax = MAX_SHIFT_LETTERS - shiftLetters;

    const completedDays = Math.max(0, shiftDay - 1);
    const currentHour = kigali.hour;
    const currentMinute = kigali.minute;
    const fractionOfToday = (currentHour + currentMinute / 60) / 24;
    const preciseDaysElapsed = completedDays + fractionOfToday;

    const dailyMax = MAX_SHIFT_LETTERS / totalDaysInShift;
    const dailyMin = (MAX_SHIFT_LETTERS * 0.9) / totalDaysInShift;

    const maxPace = preciseDaysElapsed * dailyMax;
    const minPace = preciseDaysElapsed * dailyMin;

    const remainingDaysInShift = Math.max(1, totalDaysInShift - shiftDay + 1);
    const chunkPacingTarget = Math.round(remainingToMax / remainingDaysInShift);

    let shiftStatus = {
      medal: "None",
      message: "",
      variant: "light",
      behind: 0,
      isLastDay: day === 15 || day === lastDayOfMonth,
      shiftDay,
      totalDaysInShift,
      isShift1,
      currentDay: day,
      chunkPacingTarget,
    };

    if (shiftLetters >= maxPace) {
      shiftStatus.medal = "🥇 Gold";
      shiftStatus.message = `Elite Performance! Only ${remainingToMax} letters left to reach your shift cap.`;
      shiftStatus.variant = "warning";
    } else if (shiftLetters >= minPace) {
      const toGold = Math.ceil(maxPace - shiftLetters);
      shiftStatus.medal = "🥈 Silver";
      shiftStatus.message = `Optimal Pace. You need ${toGold} more letters to hit the Gold track!`;
      shiftStatus.variant = "secondary";
    } else if (shiftLetters >= maxPace * 0.8) {
      const toSilver = Math.ceil(minPace - shiftLetters);
      shiftStatus.medal = "🥉 Bronze";
      shiftStatus.message = `Slightly behind pace. Add ${toSilver} more letters to reach Silver territory.`;
      shiftStatus.variant = "success";
    } else {
      shiftStatus.behind = Math.round(maxPace * 0.8 - shiftLetters);
      shiftStatus.medal = "⚠️ Danger";
      shiftStatus.message = `DANGER: You are ${shiftStatus.behind} letters behind the safety guard!`;
      shiftStatus.variant = "danger";
    }

    let projectedPay = 0;
    if (shiftStatus.medal.includes("Gold")) {
      projectedPay = MAX_SHIFT_LETTERS * RATE_PER_LETTER;
    } else if (shiftStatus.medal.includes("Silver")) {
      projectedPay =
        Math.max(shiftLetters, MAX_SHIFT_LETTERS * 0.9) * RATE_PER_LETTER;
    } else if (shiftStatus.medal.includes("Bronze")) {
      projectedPay =
        Math.max(shiftLetters, MAX_SHIFT_LETTERS * 0.8) * RATE_PER_LETTER;
    } else {
      projectedPay = shiftLetters * RATE_PER_LETTER;
    }

    shiftStatus.projectedPay = projectedPay;
    shiftStatus.potentialLoss =
      MAX_SHIFT_LETTERS * RATE_PER_LETTER - projectedPay;

    // Live dynamic emergency fund target (Allocations / Monthly Target)
    const emergencyTarget = (liveIncome * emergencyPct) / 100;
    const effectiveInvestmentVal =
      currentInvestmentValue > 0 ? currentInvestmentValue : n(b.investment);

    // Financial Health Metrics use only values already stored in the app.
    // A missing emergency target or essentials budget earns no points for
    // that component rather than silently awarding a perfect score.
    const financialHealth = calculateFinancialHealth({
      emergencyBalance: actualEmergencyBalance,
      emergencyTarget,
      investmentValue: effectiveInvestmentVal,
      liveIncome,
      walletBalance: liveBalance,
      actualExpenses: n(expensesRows[0]?.totalSpent),
      plannedEssentials,
    });
    const efCompletionPct = financialHealth.efCompletionPct;
    const investRatio = financialHealth.investRatioPct;
    const score = financialHealth.wealthScore;
    const financialHealthBreakdown = financialHealth.breakdown;
    const financialStage = financialHealth.financialStage;

    await ensureDailyLetterTable();
    const dailyLetterStatus = await getDailyPacingStatus();
    const leaderboard = await getShiftLeaderboard();

    res.json({
      wealthScore: score,
      financialStage,
      financialHealthBreakdown,
      emergencyTarget, // Dynamic target for MonthlyBudget progress
      pendingEmergencyTotal, // Static snapshot total for Pending Emergency Target Widget
      walletBalance: liveBalance,
      schoolFeesBalance,
      investmentReserveBalance,
      emergencyReserveBalance: actualEmergencyBalance,
      stagedSalaryPortion, // Static salary allocation snapshot
      stagedSidePortion, // Static side income allocation snapshot
      efCompletionPct: Math.round(efCompletionPct),
      seedRatio: Math.round(investRatio),
      essentials: plannedEssentials,
      shiftStatus,
      dailyLetterTarget: dailyLetterStatus.dailyTarget,
      dailyLetterCount: dailyLetterStatus.dailyLetterCount,
      dailyLettersRemaining: dailyLetterStatus.dailyRemaining,
      dailyTargetReached: dailyLetterStatus.targetReached,
      dailyNotificationSent: dailyLetterStatus.notificationSent,
      dailyLetterDate: dailyLetterStatus.date,
      dailyRequiredPerDay: dailyLetterStatus.currentRequiredPerDay,
      dailyShiftDay: dailyLetterStatus.shiftDay,
      dailyShiftTotalDays: dailyLetterStatus.totalDaysInShift,
      dailyShiftLetters: dailyLetterStatus.shiftLetters,
      dailyShiftLettersRemaining: dailyLetterStatus.remainingShiftLetters,
      dailyRemainingDaysInShift: dailyLetterStatus.remainingDaysInShift,
      leaderboard,
      monthlyBudget: {
        ...b,
        emergencyFund: actualEmergencyBalance,
        salary: liveSalary,
        balance: liveBalance,
        remainingBalance: liveBalance,
      },
    });
  } catch (err) {
    console.error("Dashboard Error:", err);
    res.status(500).json({ error: err.message });
  }
};

export const updateLetters = async (req, res) => {
  const { newLetters } = req.body;
  const num = Number(newLetters);

  if (!Number.isFinite(num) || num <= 0 || !Number.isInteger(num)) {
    return res
      .status(400)
      .json({ error: "Please provide a positive whole number of letters." });
  }

  const connection = await pool.getConnection();
  try {
    await ensureDailyLetterTable();
    await connection.beginTransaction();

    const [rows] = await connection.query(
      "SELECT translatedLetters, shiftLetters FROM MonthlyBudget WHERE id = 1 FOR UPDATE",
    );

    if (!rows.length) {
      await connection.rollback();
      return res.status(404).json({ error: "Budget row not found." });
    }

    // Snapshot the rank before this entry. The leaderboard is calculated from
    // the same shift state and tie-breaking rules used by the frontend widget.
    const leaderboardBefore = await getShiftLeaderboard(connection);
    const rankBefore = rankShiftLeaderboard(leaderboardBefore);

    const currentTotal = Number(rows[0].translatedLetters || 0) + num;
    const currentShift = Number(rows[0].shiftLetters || 0) + num;

    if (currentShift > MAX_SHIFT_LETTERS) {
      await connection.rollback();
      return res.status(400).json({
        error: `Limit reached! You can only add ${MAX_SHIFT_LETTERS - Number(rows[0].shiftLetters || 0)} more letters this shift.`,
      });
    }

    const newSalary = currentTotal * RATE_PER_LETTER;

    await connection.query(
      "UPDATE MonthlyBudget SET translatedLetters = ?, shiftLetters = ?, salary = ? WHERE id = 1",
      [currentTotal, currentShift, newSalary],
    );

    const dailyUpdate = await recordDailyLetters(connection, num);
    const leaderboardAfter = await getShiftLeaderboard(connection);
    const rankAfter = rankShiftLeaderboard(leaderboardAfter);

    await connection.commit();

    // Leaderboard motivation is best-effort and only sent when the displayed
    // rank improves. A push failure never rolls back recorded letters.
    if (rankAfter.userRank < rankBefore.userRank) {
      try {
        await sendLeaderboardOvertakeNotification({
          previousRank: rankBefore.userRank,
          newRank: rankAfter.userRank,
          positionsGained: rankBefore.userRank - rankAfter.userRank,
          lettersToOvertake: rankAfter.lettersToOvertake,
          nextCompetitorName: rankAfter.nextCompetitor?.name,
          nextCompetitorRank: rankAfter.nextCompetitor?.rank,
        });
      } catch (pushError) {
        console.error("Leaderboard overtake push error:", pushError);
      }
    }

    // Push is best-effort: a missing VAPID configuration or a failed push
    // must never undo a successfully recorded letter count.
    if (dailyUpdate.justReached) {
      try {
        await sendDailyTargetReachedNotification({
          dailyTarget: dailyUpdate.dailyTarget,
          letterCount: dailyUpdate.dailyLetterCount,
          date: dailyUpdate.date,
        });
      } catch (pushError) {
        console.error("Daily target push error:", pushError);
      }
    }

    res.json({
      success: true,
      addedLetters: num,
      translatedLetters: currentTotal,
      shiftLetters: currentShift,
      dailyLetterTarget: dailyUpdate.dailyTarget,
      dailyLetterCount: dailyUpdate.dailyLetterCount,
      dailyLettersRemaining: dailyUpdate.dailyRemaining,
      dailyTargetReached: dailyUpdate.targetReached,
      dailyRequiredPerDay: dailyUpdate.currentRequiredPerDay,
      dailyShiftDay: dailyUpdate.shiftDay,
      dailyShiftTotalDays: dailyUpdate.totalDaysInShift,
      dailyShiftLetters: dailyUpdate.shiftLetters,
      dailyShiftLettersRemaining: dailyUpdate.remainingShiftLetters,
      dailyRemainingDaysInShift: dailyUpdate.remainingDaysInShift,
    });
  } catch (err) {
    try {
      await connection.rollback();
    } catch (_) {}
    console.error("Update Letters Error:", err);
    res.status(500).json({ error: err.message });
  } finally {
    connection.release();
  }
};

export const resetShift = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [rows] = await connection.query(
      "SELECT shiftLetters, salary, otherIncome FROM MonthlyBudget WHERE id = 1",
    );

    if (rows.length > 0) {
      const currentShiftLetters = n(rows[0].shiftLetters);
      const earnedAmount = currentShiftLetters * RATE_PER_LETTER;
      // 1. Move Salary into PendingEarnings
      if (earnedAmount > 0) {
        await connection.query(
          `INSERT INTO PendingEarnings (amount, description, is_collected, earned_date)
           VALUES (?, ?, 0, NOW())`,
          [earnedAmount, `Shift Salary (${currentShiftLetters} letters)`],
        );
      }

      // Emergency targets are snapshotted only by Reset Month.
    }

    // 3. Reset active budget counters for next shift
    await connection.query(`
      UPDATE MonthlyBudget 
      SET shiftLetters = 0, 
          translatedLetters = 0, 
          salary = 0,
          otherIncome = 0
      WHERE id = 1
    `);

    await connection.commit();
    res.json({
      message:
        "Shift reset successful! Earnings buffered. Emergency targets are snapshotted only by Reset Month.",
    });
  } catch (err) {
    await connection.rollback();
    console.error("Reset Shift Error:", err);
    res.status(500).json({ error: err.message });
  } finally {
    connection.release();
  }
};

export const updateMonthlyBudget = async (req, res) => {
  const { id } = req.params;
  const incoming = req.body;

  try {
    const [rows] = await pool.query(
      "SELECT * FROM MonthlyBudget WHERE id = ?",
      [id],
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Budget row not found" });
    }

    const current = { ...rows[0], ...incoming };

    // Pending emergency snapshots are frozen only by Reset Month.

    const [templates] = await pool.query(
      "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
    );
    const emergencyPct =
      templates.length > 0 ? n(templates[0].emergency_pct) : 0;
    const income = n(current.salary) + n(current.otherIncome);
    const emergencyTarget = (income * emergencyPct) / 100;

    let finalInvestment = n(current.investment);
    let locked = false;

    if (n(current.emergencyFund) < emergencyTarget) {
      if (finalInvestment > 0) {
        finalInvestment = 0;
        locked = true;
      }
    }

    const sql = `UPDATE MonthlyBudget SET 
      salary=?, otherIncome=?, rent=?, schoolSaving=?, phoneInternet=?, electricityWater=?, 
      food=?, miscellaneous=?, medical=?, familySupport=?, emergencyFund=?, investment=?
      WHERE id=?`;

    await pool.query(sql, [
      n(current.salary),
      n(current.otherIncome),
      n(current.rent),
      n(current.schoolSaving),
      n(current.phoneInternet),
      n(current.electricityWater),
      n(current.food),
      n(current.miscellaneous),
      n(current.medical),
      n(current.familySupport),
      n(current.emergencyFund),
      finalInvestment,
      id,
    ]);

    res.json({
      message: locked
        ? `Investment Locked: ${(emergencyTarget - n(current.emergencyFund)).toLocaleString()} RWF more needed in Emergency Fund.`
        : "Budget updated successfully.",
      investmentLocked: locked,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
