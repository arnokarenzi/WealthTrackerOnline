import { pool } from "../models/MonthlyBudget.js";

const getKigaliTime = () => {
  const now = new Date();
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: "Africa/Kigali",
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
    hour12: false,
  });
  const parts = Object.fromEntries(
    formatter.formatToParts(now).map((p) => [p.type, p.value]),
  );

  const year = parseInt(parts.year, 10);
  const month = parseInt(parts.month, 10);
  const day = parseInt(parts.day, 10);
  let hour = parseInt(parts.hour, 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(parts.minute, 10);
  const second = parseInt(parts.second, 10);

  const pad = (num) => String(num).padStart(2, "0");
  const dateString = `${year}-${pad(month)}-${pad(day)}`;
  const dateTimeString = `${year}-${pad(month)}-${pad(day)} ${pad(hour)}:${pad(minute)}:${pad(second)}`;
  const lastDayOfMonth = new Date(year, month, 0).getDate();

  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    dateString,
    dateTimeString,
    lastDayOfMonth,
  };
};

const n = (v) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : 0;
};

const RATE_PER_LETTER = 245;
const MAX_SHIFT_LETTERS = 750;

export const getDashboard = async (req, res) => {
  try {
    const kigali = getKigaliTime();

    const [rows] = await pool.query("SELECT * FROM MonthlyBudget WHERE id = 1");
    if (!rows.length) {
      return res.status(404).json({ error: "Budget row not found" });
    }
    const b = rows[0];
    const currentMonth = Number(b.month);
    const currentYear = Number(b.year);

    const [templates] = await pool.query(
      "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
    );
    const emergencyPct =
      templates.length > 0 ? n(templates[0].emergency_pct) : 0;

    const [expensesRows] = await pool.query(
      `SELECT IFNULL(SUM(amount), 0) AS totalSpent 
       FROM DailyExpense 
       WHERE MONTH(expenseDate) = ? AND YEAR(expenseDate) = ?`,
      [currentMonth, currentYear],
    );

    const [investmentRows] = await pool.query(
      `SELECT IFNULL(SUM(principal_invested), 0) AS totalPrincipal, 
              IFNULL(SUM(current_value), 0) AS totalValue 
       FROM ActualInvestments 
       WHERE month = ? AND year = ?`,
      [currentMonth, currentYear],
    );
    const currentInvestmentValue = n(investmentRows[0].totalValue);

    // Fetch actual saved balance from EmergencyFund table
    const [efRows] = await pool.query(
      "SELECT current_amount FROM EmergencyFund WHERE id = 1 LIMIT 1",
    );
    const actualEmergencyBalance =
      efRows.length > 0
        ? Math.max(n(b.emergencyFund), n(efRows[0].current_amount))
        : n(b.emergencyFund);

    // Fetch static un-deposited emergency snapshot balances for the Pending Target Widget
    const [[snapshotRows]] = await pool.query(
      `SELECT 
         IFNULL(SUM(salary_allocation), 0) AS stagedSalaryEmergency, 
         IFNULL(SUM(side_income_allocation), 0) AS stagedSideEmergency 
       FROM PendingEmergencySnapshots 
       WHERE is_deposited = 0`,
    );
    const stagedSalaryPortion = n(snapshotRows?.stagedSalaryEmergency);
    const stagedSidePortion = n(snapshotRows?.stagedSideEmergency);
    const pendingEmergencyTotal =
      Math.round((stagedSalaryPortion + stagedSidePortion) * 100) / 100;

    const liveSalary = n(b.translatedLetters) * RATE_PER_LETTER;
    const liveIncome = liveSalary + n(b.otherIncome);
    const liveBalance = n(b.balance);

    await pool.query("UPDATE MonthlyBudget SET salary = ? WHERE id = 1", [
      liveSalary,
    ]);

    const plannedEssentials =
      n(b.rent) +
      n(b.phoneInternet) +
      n(b.electricityWater) +
      n(b.food) +
      n(b.miscellaneous) +
      n(b.medical) +
      n(b.familySupport);

    const day = kigali.day;
    const lastDayOfMonth = kigali.lastDayOfMonth;

    const isShift1 = day <= 15;
    const totalDaysInShift = isShift1 ? 15 : lastDayOfMonth - 15;
    const shiftDay = isShift1 ? day : day - 15;

    const shiftLetters = n(b.shiftLetters);
    const remainingToMax = MAX_SHIFT_LETTERS - shiftLetters;

    const completedDays = Math.max(0, shiftDay - 1);
    const currentHour = kigali.hour;
    const currentMinute = kigali.minute;
    const fractionOfToday = (currentHour + currentMinute / 60) / 24;
    const preciseDaysElapsed = completedDays + fractionOfToday;

    const dailyMax = MAX_SHIFT_LETTERS / totalDaysInShift;
    const dailyMin = (MAX_SHIFT_LETTERS * 0.9) / totalDaysInShift;

    const maxPace = preciseDaysElapsed * dailyMax;
    const minPace = preciseDaysElapsed * dailyMin;

    const remainingDaysInShift = Math.max(1, totalDaysInShift - shiftDay + 1);
    const chunkPacingTarget = Math.round(remainingToMax / remainingDaysInShift);

    let shiftStatus = {
      medal: "None",
      message: "",
      variant: "light",
      behind: 0,
      isLastDay: day === 15 || day === lastDayOfMonth,
      shiftDay,
      totalDaysInShift,
      isShift1,
      currentDay: day,
      chunkPacingTarget,
    };

    if (shiftLetters >= maxPace) {
      shiftStatus.medal = "🥇 Gold";
      shiftStatus.message = `Elite Performance! Only ${remainingToMax} letters left to reach your shift cap.`;
      shiftStatus.variant = "warning";
    } else if (shiftLetters >= minPace) {
      const toGold = Math.ceil(maxPace - shiftLetters);
      shiftStatus.medal = "🥈 Silver";
      shiftStatus.message = `Optimal Pace. You need ${toGold} more letters to hit the Gold track!`;
      shiftStatus.variant = "secondary";
    } else if (shiftLetters >= maxPace * 0.8) {
      const toSilver = Math.ceil(minPace - shiftLetters);
      shiftStatus.medal = "🥉 Bronze";
      shiftStatus.message = `Slightly behind pace. Add ${toSilver} more letters to reach Silver territory.`;
      shiftStatus.variant = "success";
    } else {
      shiftStatus.behind = Math.round(maxPace * 0.8 - shiftLetters);
      shiftStatus.medal = "⚠️ Danger";
      shiftStatus.message = `DANGER: You are ${shiftStatus.behind} letters behind the safety guard!`;
      shiftStatus.variant = "danger";
    }

    let projectedPay = 0;
    if (shiftStatus.medal.includes("Gold")) {
      projectedPay = MAX_SHIFT_LETTERS * RATE_PER_LETTER;
    } else if (shiftStatus.medal.includes("Silver")) {
      projectedPay =
        Math.max(shiftLetters, MAX_SHIFT_LETTERS * 0.9) * RATE_PER_LETTER;
    } else if (shiftStatus.medal.includes("Bronze")) {
      projectedPay =
        Math.max(shiftLetters, MAX_SHIFT_LETTERS * 0.8) * RATE_PER_LETTER;
    } else {
      projectedPay = shiftLetters * RATE_PER_LETTER;
    }

    shiftStatus.projectedPay = projectedPay;
    shiftStatus.potentialLoss =
      MAX_SHIFT_LETTERS * RATE_PER_LETTER - projectedPay;

    // Live dynamic emergency fund target (Allocations / Monthly Target)
    const emergencyTarget = (liveIncome * emergencyPct) / 100;
    const efCompletionPct =
      emergencyTarget > 0
        ? Math.min((actualEmergencyBalance / emergencyTarget) * 100, 100)
        : 100;

    const effectiveInvestmentVal =
      currentInvestmentValue > 0 ? currentInvestmentValue : n(b.investment);
    const investRatio =
      liveIncome > 0 ? (effectiveInvestmentVal / liveIncome) * 100 : 0;

    let score = 0;
    score += (efCompletionPct / 100) * 40;
    score += Math.min((investRatio / 20) * 30, 30);
    if (liveBalance > 0) score += 10;

    const stages = [
      "Priority: Build Safety",
      "Stability Phase",
      "Investing Mode",
      "Wealth Builder",
    ];
    const stageIndex = score <= 40 ? 0 : score <= 60 ? 1 : score <= 80 ? 2 : 3;

    res.json({
      wealthScore: Math.round(score),
      financialStage: stages[stageIndex],
      emergencyTarget, // Dynamic target for MonthlyBudget progress
      pendingEmergencyTotal, // Static snapshot total for Pending Emergency Target Widget
      stagedSalaryPortion, // Static salary allocation snapshot
      stagedSidePortion, // Static side income allocation snapshot
      efCompletionPct: Math.round(efCompletionPct),
      seedRatio: Math.round(investRatio),
      essentials: plannedEssentials,
      shiftStatus,
      monthlyBudget: {
        ...b,
        emergencyFund: actualEmergencyBalance,
        salary: liveSalary,
        balance: liveBalance,
        remainingBalance: liveBalance,
      },
    });
  } catch (err) {
    console.error("Dashboard Error:", err);
    res.status(500).json({ error: err.message });
  }
};

export const updateLetters = async (req, res) => {
  const { newLetters } = req.body;
  const num = Number(newLetters);

  try {
    const [rows] = await pool.query(
      "SELECT translatedLetters, shiftLetters FROM MonthlyBudget WHERE id = 1",
    );
    const currentTotal = rows[0].translatedLetters + num;
    const currentShift = rows[0].shiftLetters + num;

    if (currentShift > MAX_SHIFT_LETTERS) {
      return res.status(400).json({
        error: `Limit reached! You can only add ${MAX_SHIFT_LETTERS - rows[0].shiftLetters} more letters this shift.`,
      });
    }

    const newSalary = currentTotal * RATE_PER_LETTER;

    await pool.query(
      "UPDATE MonthlyBudget SET translatedLetters = ?, shiftLetters = ?, salary = ? WHERE id = 1",
      [currentTotal, currentShift, newSalary],
    );
    res.json({ success: true });
  } catch (err) {
    console.error("Update Letters Error:", err);
    res.status(500).json({ error: err.message });
  }
};

export const resetShift = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const kigali = getKigaliTime();
    await connection.beginTransaction();

    const [rows] = await connection.query(
      "SELECT shiftLetters, salary, otherIncome FROM MonthlyBudget WHERE id = 1",
    );

    if (rows.length > 0) {
      const currentShiftLetters = n(rows[0].shiftLetters);
      const earnedAmount = currentShiftLetters * RATE_PER_LETTER;
      const currentOtherIncome = n(rows[0].otherIncome);

      // 1. Move Salary into PendingEarnings
      if (earnedAmount > 0) {
        await connection.query(
          `INSERT INTO PendingEarnings (amount, description, is_collected, earned_date) 
           VALUES (?, ?, 0, ?)`,
          [
            earnedAmount,
            `Shift Salary (${currentShiftLetters} letters)`,
            kigali.dateTimeString,
          ],
        );
      }

      // 2. Snapshot Emergency Allocations into PendingEmergencySnapshots
      const [templates] = await connection.query(
        "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
      );
      const emergencyPct =
        templates.length > 0 ? n(templates[0].emergency_pct) : 0;

      const emergencyFromSalary = (earnedAmount * emergencyPct) / 100;
      const emergencyFromSide = (currentOtherIncome * emergencyPct) / 100;

      if (emergencyFromSalary > 0 || emergencyFromSide > 0) {
        await connection.query(
          `INSERT INTO PendingEmergencySnapshots 
           (salary_allocation, side_income_allocation, month_label, earned_date, is_deposited) 
           VALUES (?, ?, ?, ?, FALSE)`,
          [
            emergencyFromSalary,
            emergencyFromSide,
            `Shift: ${kigali.dateString}`,
            kigali.dateTimeString,
          ],
        );
      }
    }

    // 3. Reset active budget counters for next shift
    await connection.query(`
      UPDATE MonthlyBudget 
      SET shiftLetters = 0, 
          translatedLetters = 0, 
          salary = 0,
          otherIncome = 0
      WHERE id = 1
    `);

    await connection.commit();
    res.json({
      message:
        "Shift reset successful! Earnings buffered and emergency allocations snapshotted.",
    });
  } catch (err) {
    await connection.rollback();
    console.error("Reset Shift Error:", err);
    res.status(500).json({ error: err.message });
  } finally {
    connection.release();
  }
};

export const updateMonthlyBudget = async (req, res) => {
  const { id } = req.params;
  const incoming = req.body;

  try {
    const [rows] = await pool.query(
      "SELECT * FROM MonthlyBudget WHERE id = ?",
      [id],
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Budget row not found" });
    }

    const current = { ...rows[0], ...incoming };

    if (incoming.otherIncome !== undefined) {
      const oldOther = n(rows[0].otherIncome);
      const newOther = n(incoming.otherIncome);
      const diff = newOther - oldOther;

      if (diff > 0) {
        const [templates] = await pool.query(
          "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
        );
        const emergencyPct =
          templates.length > 0 ? n(templates[0].emergency_pct) : 0;
        const sideEmergencyAllocation = (diff * emergencyPct) / 100;

        if (sideEmergencyAllocation > 0) {
          await pool.query(
            `INSERT INTO PendingEmergencySnapshots 
             (salary_allocation, side_income_allocation, month_label, earned_date, is_deposited) 
             VALUES (0, ?, ?, NOW(), FALSE)`,
            [sideEmergencyAllocation, "Side Income"],
          );
        }
      }
    }

    const [templates] = await pool.query(
      "SELECT emergency_pct FROM AllocationTemplates WHERE user_id = 1 LIMIT 1",
    );
    const emergencyPct =
      templates.length > 0 ? n(templates[0].emergency_pct) : 0;
    const income = n(current.salary) + n(current.otherIncome);
    const emergencyTarget = (income * emergencyPct) / 100;

    let finalInvestment = n(current.investment);
    let locked = false;

    if (n(current.emergencyFund) < emergencyTarget) {
      if (finalInvestment > 0) {
        finalInvestment = 0;
        locked = true;
      }
    }

    const sql = `UPDATE MonthlyBudget SET 
      salary=?, otherIncome=?, rent=?, schoolSaving=?, phoneInternet=?, electricityWater=?, 
      food=?, miscellaneous=?, medical=?, familySupport=?, emergencyFund=?, investment=?
      WHERE id=?`;

    await pool.query(sql, [
      n(current.salary),
      n(current.otherIncome),
      n(current.rent),
      n(current.schoolSaving),
      n(current.phoneInternet),
      n(current.electricityWater),
      n(current.food),
      n(current.miscellaneous),
      n(current.medical),
      n(current.familySupport),
      n(current.emergencyFund),
      finalInvestment,
      id,
    ]);

    res.json({
      message: locked
        ? `Investment Locked: ${(emergencyTarget - n(current.emergencyFund)).toLocaleString()} RWF more needed in Emergency Fund.`
        : "Budget updated successfully.",
      investmentLocked: locked,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
