// Force the Vercel Node.js environment to use Kigali time
process.env.TZ = "Africa/Kigali";

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import monthlyBudgetRoutes from "./routes/monthlyBudgetRoutes.js";
import dailyExpenseRoutes from "./routes/dailyExpenseRoutes.js";
import savingsGoalRoutes from "./routes/savingsGoalRoutes.js";
import schoolFeesRoutes from "./routes/schoolFeesRoutes.js";
import investmentRoutes from "./routes/investmentRoutes.js";
import allocationRoutes from "./routes/allocationRoutes.js";
import gratitudeRoutes from "./routes/gratitudeRoutes.js";
import alertsRoutes from "./routes/alertsRoutes.js";
import emergencyRoutes from "./routes/emergencyRoutes.js";
import dashboardRoutes from "./routes/dashboardRoutes.js";
import pendingEarningsRouter from "./routes/pendingEarningsRoutes.js";
import pushRoutes from "./routes/pushRoutes.js";
import dailyLetterRoutes from "./routes/dailyLetterRoutes.js";
import cronRoutes from "./routes/cronRoutes.js";
import financeFeaturesRoutes from "./routes/financeFeaturesRoutes.js";
import friendPortalLettersRoutes from "./routes/friendPortalLettersRoutes.js";

dotenv.config();

// Global error handlers to prevent silent server crashes
process.on("uncaughtException", (err) => {
  console.error("FATAL UNCAUGHT EXCEPTION:", err);
});
process.on("unhandledRejection", (reason, promise) => {
  console.error("UNHANDLED REJECTION:", reason);
});

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Main App API Routes
app.use("/api/emergency", emergencyRoutes);
app.use("/api/monthly-budget", monthlyBudgetRoutes);
app.use("/api/daily-expenses", dailyExpenseRoutes);
app.use("/api/savings-goals", savingsGoalRoutes);
app.use("/api/school-fees", schoolFeesRoutes);
app.use("/api/actual-investments", investmentRoutes);
app.use("/api/investments", investmentRoutes);
app.use("/api/allocations", allocationRoutes);
app.use("/api/gratitude", gratitudeRoutes);
app.use("/api/alerts", alertsRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/pending-earnings", pendingEarningsRouter);
app.use("/api/push", pushRoutes);
app.use("/api/daily-letters", dailyLetterRoutes);
app.use("/api/friend-portal-letters", friendPortalLettersRoutes);
app.use("/api/cron", cronRoutes);
app.use("/api", financeFeaturesRoutes);

app.get("/", (req, res) => {
  res.send("WealthTrackerOnline Backend API is operating perfectly!");
});

app.listen(PORT, () => {
  console.log(`Server is running successfully on port ${PORT}`);
});
